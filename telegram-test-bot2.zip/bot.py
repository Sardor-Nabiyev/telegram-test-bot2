# bot.py mazmuni bu yerda bo'ladi
