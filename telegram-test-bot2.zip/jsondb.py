# jsondb.py contenti keyin to'ldiriladi
