import os
TOKEN = os.getenv('TOKEN')
ADMIN_CODE = os.getenv('ADMIN_CODE')
